/* multidimensional_array.hh (version G4double)

   jpl_060517 :

*/

#ifndef multidimensional_array_hh
#define multidimensional_array_hh 1

#include <vector>

#include <globals.hh>

#include <cstdio>
#include <cstdlib>
#include <cstring>

using namespace std;

class N_Array { 
public :

  G4double* data;

  vector<G4int> siz;
  G4int dim, len;
  
  G4int ix_concentrate (vector<G4int> const &nix);
  vector<G4int> ix_deploy (G4int ix);
  
  N_Array ();
  N_Array (vector<G4int> const &d);
  N_Array (N_Array const &a);

  ~N_Array ();
  
  N_Array& operator=(N_Array const &na);
  bool operator==(N_Array const &rh);
  bool operator!=(N_Array const &rh);

  void put (vector<G4int> const &ix, G4double const &value);
  G4double get (vector<G4int> const &ix);
  void write (FILE *f);
  G4int read (FILE *f);
  G4int read (vector<G4int> const &lix, FILE *f); // mix head fixed, data from position
  vector<G4int> mask (vector<G4int> const &v, vector<G4int> const &ix_mask);
  N_Array marginalize (vector<G4int> const &ix_list);
};

#endif
