#ifndef ExN02PrimaryGeneratorAction_new_h
#define ExN02PrimaryGeneratorAction_new_h 1

#include "G4VUserPrimaryGeneratorAction.hh"
//#include "bxdecay0_g4/primary_generator_action.hh"

#include "G4ParticleGun.hh"
#include "globals.hh"

//Geant4 classes
class G4ParticleGun;
class G4Event;

//BxDecay0 Primary Generator Action class
//class PrimaryGeneratorAction;






//Primary generator action class with particle gun



class ExN02PrimaryGeneratorAction_new: public G4VUserPrimaryGeneratorAction
{
	public:
		ExN02PrimaryGeneratorAction_new();
		virtual ~ExN02PrimaryGeneratorAction_new();
		
		virtual void GeneratePrimaries(G4Event*);

		virtual void GenerateOpeningAngles(G4double, G4double);
		
		const G4ParticleGun* GetParticleGun() const { return fParticleGun; }

		
		
	private:
		G4ParticleGun* fParticleGun;
		G4double alpha, beta;
		G4ThreeVector direction = G4ThreeVector(0.,0.,0.);

		
};

#endif
