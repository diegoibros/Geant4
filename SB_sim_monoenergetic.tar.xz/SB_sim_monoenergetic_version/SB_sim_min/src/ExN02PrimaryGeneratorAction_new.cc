#include "ExN02PrimaryGeneratorAction_new.hh"
//#include <bxdecay0/decay0_generator.h>

#include "G4RunManager.hh"
#include "G4Event.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4IonTable.hh"
#include "G4ParticleDefinition.hh"
#include "G4ChargedGeantino.hh"
#include "G4SystemOfUnits.hh"
#include "Randomize.hh"
#include "G4ParticleMomentum.hh"
#include "time.h"
#include <iostream>
#include <fstream>


ExN02PrimaryGeneratorAction_new::ExN02PrimaryGeneratorAction_new() : G4VUserPrimaryGeneratorAction(), fParticleGun(nullptr), alpha(0.), beta(0.)   

{	
	
	//fParticleGun = (G4ParticleGun*) GetParticleGun();

	fParticleGun = new G4ParticleGun(1);


	//ConfigurationInterface config_new = ConfigurationInterface();
	//G4cout << "esto essss" << config_new.nuclide << G4endl;

	
	//bxdecay0_g4::PrimaryGeneratorAction::SetConfiguration(config_new);
	
	//default particle kinematics
	
	
}

ExN02PrimaryGeneratorAction_new::~ExN02PrimaryGeneratorAction_new()
{
	delete fParticleGun;
}

void ExN02PrimaryGeneratorAction_new::GeneratePrimaries(G4Event* anEvent)
{

		


	
	
	
	
	
	//Position
	/*
	G4double x0=0.*cm, y0=0.*cm, z0=0.*cm;
	fParticleGun->SetParticlePosition(G4ThreeVector(x0,y0,z0));

	//Generate particles in the solid angle desired

	//Here we are going to produce the direction of the electron in our solid angle desired
    G4double pi = 3.14159265358979323846; 

        //Define opening angle as alpha
        //From geometrical definition (at distance 32cm the field will extend vertically from +/- 4cm so max interesting angle is 125 mrad) 
        //G4double alpha = 0.125;  
    G4double alpha = 0.250;     //horizontal opening angle
    G4double beta = 0.125;      //vertical opening angle


    G4double theta = (pi/2) + 2*alpha*(G4UniformRand()-0.5);


        //From manual calculation, for 100 mrad opening in phi, use same function acos(1-2*x); and set from x=0.450083 to 0.549917
    G4double phi = acos(2*beta*(G4UniformRand()-0.5));

    G4double T1 = sin(phi)*cos(theta);
    G4double T2 = sin(phi)*sin(theta);
    G4double T3 = cos(phi); 
        
        //Set the direction of the electron

    G4ThreeVector * newdirection = new G4ThreeVector(T1,T2,T3);
    
	//create vertex
	*/

	//position of the source: point
	G4double position_x = (-180.)*mm;

 	//G4double position2 = (-334.2)*mm; //Fixed position 
  	G4double position_y = (-320.)*mm; //Fixed position 
  
    //G4double position2 = (-2.501)*mm;
 
  	G4double position_z = (0.)*mm;

 	G4ThreeVector pos = G4ThreeVector(position_x,position_y,position_z);
 	std::ifstream opening_angle("primary_angles.txt");
 	G4double angle1, angle2;
 	opening_angle >> angle1;
 	opening_angle >> angle2;

 	GenerateOpeningAngles(angle1, angle2);


 	const G4String & ParticleName = "e-";
 	G4ParticleTable* particleTable = G4ParticleTable::GetParticleTable();
 	G4ParticleDefinition* particle = particleTable->FindParticle(ParticleName);

 	fParticleGun->SetParticleDefinition(particle);
 	std::ifstream energyfile("primary_E.txt");
 	G4double prim_E;
 	energyfile >> prim_E;
 	fParticleGun->SetParticleEnergy(prim_E *keV);
	fParticleGun->SetParticlePosition(pos);
	fParticleGun->SetParticleMomentumDirection(direction);
	fParticleGun->GeneratePrimaryVertex(anEvent);
}

void ExN02PrimaryGeneratorAction_new::GenerateOpeningAngles(G4double alpha, G4double beta)
{

	G4double pi = 3.14159265358979323846; 

        //Define opening angle as alpha
        //From geometrical definition (at distance 32cm the field will extend vertically from +/- 4cm so max interesting angle is 125 mrad) 
        //G4double alpha = 0.125;  
  

    G4double theta = (pi/2) + 2*alpha*(G4UniformRand()-0.5);


        //From manual calculation, for 100 mrad opening in phi, use same function acos(1-2*x); and set from x=0.450083 to 0.549917
    G4double phi = acos(2*beta*(G4UniformRand()-0.5));

    G4double T1 = sin(phi)*cos(theta);
    G4double T2 = sin(phi)*sin(theta);
    G4double T3 = cos(phi); 
        
        //Set the direction of the electron

    direction = G4ThreeVector(T1,T2,T3);
}
