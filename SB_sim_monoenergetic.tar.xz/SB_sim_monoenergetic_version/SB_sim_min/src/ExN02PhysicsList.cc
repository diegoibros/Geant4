/* jplG4_PL.cc

   jpl_050525 :

*/

#include "ExN02PhysicsList.hh"
#include "G4ParticleTypes.hh"
#include "G4ProcessManager.hh"

#include "G4SystemOfUnits.hh"

ExN02PhysicsList::ExN02PhysicsList():  G4VUserPhysicsList()
{
   defaultCutValue = 0.1*mm;

}

ExN02PhysicsList::~ExN02PhysicsList()
{}

#include "G4LeptonConstructor.hh"
#include "G4BosonConstructor.hh"
#include "G4BaryonConstructor.hh"

void ExN02PhysicsList::ConstructParticle()
{
  G4LeptonConstructor pLc; 
  pLc.ConstructParticle ();
  
  G4BosonConstructor pBc; 
  pBc.ConstructParticle ();
  
  G4BaryonConstructor pHc; 
  pHc.ConstructParticle ();
}
/*
#include "G4LowEnergyCompton.hh"
#include "G4LowEnergyPolarizedCompton.hh"
#include "G4LowEnergyGammaConversion.hh"
#include "G4LowEnergyPhotoElectric.hh"
#include "G4LowEnergyRayleigh.hh"

#include "G4PenelopeCompton.hh"
#include "G4PenelopeGammaConversion.hh"
#include "G4PenelopePhotoElectric.hh"
#include "G4PenelopeRayleigh.hh"

#include "G4LivermoreComptonModel.hh"
#include "G4LivermoreGammaConversionModel.hh"
#include "G4LivermorePhotoElectricModel.hh"
#include "G4LivermoreRayleighModel.hh"

#include "G4MultipleScattering.hh"

#include "G4LowEnergyIonisation.hh"
#include "G4LowEnergyBremsstrahlung.hh"
#include "G4eplusAnnihilation.hh"

#include "G4PenelopeIonisation.hh"
#include "G4PenelopeBremsstrahlung.hh"
#include "G4PenelopeAnnihilation.hh"

#include "G4eIonisation.hh"     // jpl ? for e+
#include "G4eBremsstrahlung.hh" // jpl ? for e+

*/
#include "G4PhysicsListHelper.hh"


// gamma
#include "G4PhotoElectricEffect.hh"
#include "G4PenelopePhotoElectricModel.hh"

#include "G4ComptonScattering.hh"
#include "G4PenelopeComptonModel.hh"

#include "G4GammaConversion.hh"
#include "G4PenelopeGammaConversionModel.hh"

#include "G4RayleighScattering.hh" 
#include "G4PenelopeRayleighModel.hh"

// e-
#include "G4eMultipleScattering.hh"
#include "G4UniversalFluctuation.hh"

#include "G4eIonisation.hh"
#include "G4PenelopeIonisationModel.hh"

#include "G4eBremsstrahlung.hh"
#include "G4PenelopeBremsstrahlungModel.hh"

// e+ only

#include "G4eplusAnnihilation.hh"
#include "G4PenelopeAnnihilationModel.hh"

// msc models
//#include "G4UrbanMscModel93.hh"
//#include "G4UrbanMscModel95.hh"
//#include "G4GoudsmitSaundersonMscModel.hh"
//#include "G4WentzelVIModel.hh"
#include "G4eMultipleScattering.hh"
#include "G4CoulombScattering.hh"

//


#include "G4LossTableManager.hh"
#include "G4VAtomDeexcitation.hh"
#include "G4UAtomicDeexcitation.hh"
//#include "G4EmProcessOptions.hh"
#include "G4EmParameters.hh"

void ExN02PhysicsList::ConstructEM()
{
  G4PhysicsListHelper* ph = G4PhysicsListHelper::GetPhysicsListHelper();

  auto theParticleIterator = GetParticleIterator();

  theParticleIterator->reset();

  while ((*theParticleIterator)()) {

    G4ParticleDefinition *particle = theParticleIterator->value ();
    //G4ProcessManager *pmanager = particle->GetProcessManager ();
    G4String particleName = particle->GetParticleName ();
    G4double PenelopeHighEnergyLimit = 1.0*GeV;


    if (particleName == "gamma") {

      //Photo-electric effect
      G4PhotoElectricEffect* thePhotoElectricEffect = new G4PhotoElectricEffect();
      G4PenelopePhotoElectricModel* thePEPenelopeModel = new 
	G4PenelopePhotoElectricModel();   
      thePEPenelopeModel->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      thePhotoElectricEffect->AddEmModel(0,thePEPenelopeModel);
      ph->RegisterProcess(thePhotoElectricEffect, particle);

      //Compton scattering
      G4ComptonScattering* theComptonScattering = new G4ComptonScattering();
      G4PenelopeComptonModel* theComptonPenelopeModel = 
	new G4PenelopeComptonModel();
      theComptonPenelopeModel->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      theComptonScattering->AddEmModel(0,theComptonPenelopeModel);
      ph->RegisterProcess(theComptonScattering, particle);

      //Gamma conversion
      G4GammaConversion* theGammaConversion = new G4GammaConversion();
      G4PenelopeGammaConversionModel* theGCPenelopeModel = 
	new G4PenelopeGammaConversionModel();
      theGammaConversion->AddEmModel(0,theGCPenelopeModel);
      ph->RegisterProcess(theGammaConversion, particle);

      //Rayleigh scattering
      G4RayleighScattering* theRayleigh = new G4RayleighScattering();
      G4PenelopeRayleighModel* theRayleighPenelopeModel = 
	new G4PenelopeRayleighModel();
      theRayleighPenelopeModel->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      theRayleigh->AddEmModel(0,theRayleighPenelopeModel);
      ph->RegisterProcess(theRayleigh, particle);



      /*
      G4PhotoElectricEffect* thePhotoElectricEffect = new G4PhotoElectricEffect();
      thePhotoElectricEffect->SetModel(new G4PenelopePhotoElectricModel());
      ph->RegisterProcess(thePhotoElectricEffect, particle);

      G4ComptonScattering* theComptonScattering = new G4ComptonScattering();
      theComptonScattering->SetModel(new G4PenelopeComptonModel());
      ph->RegisterProcess(theComptonScattering, particle);

      G4GammaConversion* theGammaConversion = new G4GammaConversion();
      theGammaConversion->SetModel(new G4PenelopeGammaConversionModel());
      ph->RegisterProcess(theGammaConversion, particle);

      G4RayleighScattering* theRayleigh = new G4RayleighScattering();
      theRayleigh->SetModel(new G4PenelopeRayleighModel());
      ph->RegisterProcess(theRayleigh, particle);

    

      /*  
      pmanager->AddDiscreteProcess (new G4LowEnergyGammaConversion);
      pmanager->AddDiscreteProcess (new G4LowEnergyCompton);
      pmanager->AddDiscreteProcess (new G4LowEnergyPhotoElectric);
      pmanager->AddDiscreteProcess (new G4LowEnergyRayleigh);
      
      /*
      pmanager->AddDiscreteProcess(new G4PenelopePhotoElectric);
      pmanager->AddDiscreteProcess(new G4PenelopeCompton);
      pmanager->AddDiscreteProcess(new G4PenelopeGammaConversion);
      pmanager->AddDiscreteProcess(new G4PenelopeRayleigh);
*/
    
    } 
    else if (particleName == "e-") {

      G4eMultipleScattering* msc = new G4eMultipleScattering();
      msc->SetStepLimitType(fUseDistanceToBoundary);
      ph->RegisterProcess(msc, particle);

      //Ionisation
      G4eIonisation* eIoni = new G4eIonisation();
      G4PenelopeIonisationModel* theIoniPenelope = 
	new G4PenelopeIonisationModel();
      theIoniPenelope->SetHighEnergyLimit(PenelopeHighEnergyLimit);     
      eIoni->AddEmModel(0,theIoniPenelope,new G4UniversalFluctuation());
      eIoni->SetStepFunction(0.2, 100*um); //     
      ph->RegisterProcess(eIoni, particle);
      
      //Bremsstrahlung
      G4eBremsstrahlung* eBrem = new G4eBremsstrahlung();
      G4PenelopeBremsstrahlungModel* theBremPenelope = new 
	G4PenelopeBremsstrahlungModel();
      theBremPenelope->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      eBrem->AddEmModel(0,theBremPenelope);
      ph->RegisterProcess(eBrem, particle);


      /*      
      // Ionisation
      G4eIonisation* eIoni = new G4eIonisation();
      eIoni->SetEmModel(new G4PenelopeIonisationModel());
      eIoni->SetFluctModel(new G4UniversalFluctuation() );
      ph->RegisterProcess(eIoni, particle);
      
      // Bremsstrahlung
      G4eBremsstrahlung* eBrem = new G4eBremsstrahlung();
      eBrem->SetEmModel(new G4PenelopeBremsstrahlungModel());
      ph->RegisterProcess(eBrem, particle);


      /*
      G4VProcess *minusMult = new G4MultipleScattering ();
      G4VProcess *minusIon = new G4LowEnergyIonisation ();
      G4VProcess *minusBrem = new G4LowEnergyBremsstrahlung ();
      
      /*
      G4VProcess *minusMult = new G4MultipleScattering ();
      G4VProcess *minusIon = new G4PenelopeIonisation ();
      G4VProcess *minusBrem = new G4PenelopeBremsstrahlung ();
      //G4VProcess *minusBrem = new G4eBremsstrahlung ();
*/
   
      /*
      pmanager->AddProcess (minusMult);
      pmanager->AddProcess (minusIon);
      pmanager->AddProcess (minusBrem);

      pmanager->SetProcessOrdering (minusMult, idxAlongStep, 1);
      pmanager->SetProcessOrdering (minusIon, idxAlongStep, 2);

      pmanager->SetProcessOrdering (minusMult, idxPostStep, 1);
      pmanager->SetProcessOrdering (minusIon, idxPostStep, 2);
      pmanager->SetProcessOrdering (minusBrem, idxPostStep, 3);
*/
    }
    else if (particleName == "e+") {
    
      G4eMultipleScattering* msc = new G4eMultipleScattering();
      msc->SetStepLimitType(fUseDistanceToBoundary);
      ph->RegisterProcess(msc, particle);
 
      //Ionisation
      G4eIonisation* eIoni = new G4eIonisation();
      G4PenelopeIonisationModel* theIoniPenelope = 
	new G4PenelopeIonisationModel();
      theIoniPenelope->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      eIoni->AddEmModel(0,theIoniPenelope,new G4UniversalFluctuation());
      eIoni->SetStepFunction(0.2, 100*um); //     
      ph->RegisterProcess(eIoni, particle);

       //Bremsstrahlung
      G4eBremsstrahlung* eBrem = new G4eBremsstrahlung();
      G4PenelopeBremsstrahlungModel* theBremPenelope = new 
	G4PenelopeBremsstrahlungModel();
      theBremPenelope->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      eBrem->AddEmModel(0,theBremPenelope);
      ph->RegisterProcess(eBrem, particle);
      
      //Annihilation
      G4eplusAnnihilation* eAnni = new G4eplusAnnihilation();
      G4PenelopeAnnihilationModel* theAnnPenelope = new 
	G4PenelopeAnnihilationModel();
      theAnnPenelope->SetHighEnergyLimit(PenelopeHighEnergyLimit);
      eAnni->AddEmModel(0,theAnnPenelope);
      ph->RegisterProcess(eAnni, particle);





     /*      
      // Ionisation
      G4eIonisation* eIoni = new G4eIonisation();
      eIoni->SetEmModel(new G4PenelopeIonisationModel());
      eIoni->SetFluctModel(new G4UniversalFluctuation() );
      ph->RegisterProcess(eIoni, particle);
      
      // Bremsstrahlung
      G4eBremsstrahlung* eBrem = new G4eBremsstrahlung();
      eBrem->SetEmModel(new G4PenelopeBremsstrahlungModel());
      ph->RegisterProcess(eBrem, particle);
      
      //Annihilation
      G4eplusAnnihilation* eAnni = new G4eplusAnnihilation();
      eAnni->SetModel(new G4PenelopeAnnihilationModel());
      ph->RegisterProcess(eAnni, particle);



  /*    
      G4VProcess *plusMult = new G4MultipleScattering ();
      G4VProcess *plusIon = new G4eIonisation ();   // jpl : why not LowEM ?
      G4VProcess *plusBrem = new G4eBremsstrahlung ();// jpl : why not LowEM ?
      G4VProcess *plusAnn = new G4eplusAnnihilation ();
      
      /*
      G4VProcess *plusMult = new G4MultipleScattering ();
      G4VProcess *plusIon = new G4PenelopeIonisation ();   
      // G4VProcess *plusBrem = new G4eBremsstrahlung ();
      G4VProcess *plusBrem = new G4PenelopeBremsstrahlung ();
      G4VProcess *plusAnn = new G4PenelopeAnnihilation ();
*/
      /*      pmanager->AddProcess (plusMult);
      pmanager->AddProcess (plusIon);
      pmanager->AddProcess (plusBrem);
      pmanager->AddProcess (plusAnn);

      pmanager->SetProcessOrderingToFirst (plusAnn, idxAtRest);

      pmanager->SetProcessOrdering (plusMult, idxAlongStep, 1);
      pmanager->SetProcessOrdering (plusIon, idxAlongStep, 2);

      pmanager->SetProcessOrdering (plusMult, idxPostStep, 1);
      pmanager->SetProcessOrdering (plusIon, idxPostStep, 2);
      pmanager->SetProcessOrdering (plusBrem, idxPostStep, 3);
      pmanager->SetProcessOrdering (plusAnn, idxPostStep, 4);
*/
    }
  }
    
}
void ExN02PhysicsList::ConstructProcess()
{
  AddTransportation ();

  ConstructEM ();
// Em options
  //      
  //Replaced old G4EmProcessOptions
  auto opt = G4EmParameters::Instance();

  // opt.SetVerbose(7);
  
  // Multiple Coulomb scattering
  //
  //opt.SetMscStepLimitation(fUseDistanceToBoundary);
  //opt.SetMscRangeFactor(0.02);
    
  // Physics tables
  //

  opt->SetMinEnergy(100*eV);
  opt->SetMaxEnergy(10*TeV);
  //opt.SetDEDXBinning(220);
  //opt.SetLambdaBinning(220);
 

  //opt.SetSplineFlag(true);
  
  //Old
  //opt->SetPolarAngleLimit(CLHEP::pi);
  //New
  opt->SetMscThetaLimit(CLHEP::pi);


  // Ionization
  //
  //opt.SetSubCutoff(true);    

  
  // Deexcitation
  //
  G4VAtomDeexcitation* deexcitation = new G4UAtomicDeexcitation();
  G4LossTableManager::Instance()->SetAtomDeexcitation(deexcitation);
  deexcitation->SetFluo(true); 

   AddStepMax();
}
#include "G4StepLimiter.hh"
#include "G4UserSpecialCuts.hh"

void ExN02PhysicsList::AddStepMax()
{
  // Step limitation seen as a process
  G4StepLimiter* stepLimiter = new G4StepLimiter();
  G4UserSpecialCuts* userCuts = new G4UserSpecialCuts();
  
  auto theParticleIterator = GetParticleIterator();

  theParticleIterator->reset();
  while ((*theParticleIterator)()){
      G4ParticleDefinition* particle = theParticleIterator->value();
      G4ProcessManager* pmanager = particle->GetProcessManager();

      if (particle->GetPDGCharge() != 0.0)
        {
	  pmanager ->AddDiscreteProcess(stepLimiter);
	  //pmanager ->AddDiscreteProcess(userCuts);
        }
  }
}

void ExN02PhysicsList::SetCuts ()
{
  
  G4double cut = 0.1 * mm;
  //G4double cut = .05 * mm;
  SetCutValue (cut, "gamma");
  SetCutValue (cut, "e-");
  SetCutValue (cut, "e+");
  
}
