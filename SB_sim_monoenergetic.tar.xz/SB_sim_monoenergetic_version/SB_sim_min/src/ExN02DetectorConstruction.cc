

//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
// $Id: ExN02DetectorConstruction.cc,v 1.22 2010-01-22 11:57:03 maire Exp $
// GEANT4 tag $Name: not supported by cvs2svn $
//
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo...... 
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
 
#include "ExN02DetectorConstruction.hh"
#include "ExN02DetectorMessenger.hh"
#include "ExN02ChamberParameterisation.hh"
#include "ExN02NewMagneticField.hh"
#include "ExN02TrackerSD.hh"

#include "G4Material.hh"
#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4PVPlacement.hh"
#include "G4PVParameterised.hh"
#include "G4SDManager.hh"
#include "G4GeometryTolerance.hh"
#include "G4GeometryManager.hh"

#include "G4SystemOfUnits.hh"

#include "G4UserLimits.hh"
#include "G4PhysicalConstants.hh"

#include "G4VisAttributes.hh"
#include "G4Colour.hh"

#include "G4ios.hh"

#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"
#include "G4EquationOfMotion.hh"
#include "G4EqMagElectricField.hh"
#include "G4Mag_UsualEqRhs.hh"
#include "G4MagIntegratorStepper.hh"
#include "G4MagIntegratorDriver.hh"
#include "G4ChordFinder.hh"

#include "G4ExplicitEuler.hh"
#include "G4ImplicitEuler.hh"
#include "G4SimpleRunge.hh"
#include "G4SimpleHeum.hh"
#include "G4HelixExplicitEuler.hh"
#include "G4HelixImplicitEuler.hh"
#include "G4HelixSimpleRunge.hh"
#include "G4CashKarpRKF45.hh"
#include "G4RKG3_Stepper.hh"
#include "G4ElectricField.hh"

#include "G4ConstRK4.hh"
#include "G4ClassicalRK4.hh"
#include "G4Tubs.hh"
#include "G4NistManager.hh"
#include <iomanip>
#include <iostream>
#include <fstream>


#define FIELD 1
#define GLOBAL
#include "Global.h"

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
 
ExN02DetectorConstruction::ExN02DetectorConstruction()
:solidWorld(0),  logicWorld(0),  physiWorld(0),
 solidTarget(0), logicTarget(0), physiTarget(0), 
 solidTracker(0),logicTracker(0),physiTracker(0), 
 solidChamber(0),logicChamber(0),physiChamber(0), 
 TargetMater(0), ChamberMater(0),chamberParam(0),
 stepLimit(0),
 fWorldLength(0.),  fTargetLength(0.), fTrackerLength(0.),
  NbOfChambers(0) ,  ChamberWidth(0.),  ChamberSpacing(0.)//, fpMagField(0),
{
  //  fpMagField = new ExN02MagneticField();
  detectorMessenger = new ExN02DetectorMessenger(this);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
 
ExN02DetectorConstruction::~ExN02DetectorConstruction()
{
  // delete fpMagField;
  delete stepLimit;
  delete chamberParam;
  delete detectorMessenger;             
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
 
G4VPhysicalVolume* ExN02DetectorConstruction::Construct()
{
//--------- Material definition ---------

  G4double a, z;
  G4double density, temperature, pressure;
  G4int nel;
  G4NistManager* man = G4NistManager::Instance();

  //Air
  G4Element* N = new G4Element("Nitrogen", "N", z=7., a= 14.01*g/mole);
  G4Element* O = new G4Element("Oxygen"  , "O", z=8., a= 16.00*g/mole);
  density = 1.2928*mg/cm3;
  density *= 1.0e-5;
  G4double T = STP_Temperature;
  G4double P = STP_Pressure;
 
  G4Material* Air = new G4Material("Air", density, nel=2,kStateGas,T,P);
  Air->AddElement(N, 70*perCent);
  Air->AddElement(O, 30*perCent);

  //Lead
  G4Material* Pb = 
  new G4Material("Lead", z=82., a= 207.19*g/mole, density= 11.35*g/cm3);
    
  //Xenon gas
  G4Material* Xenon = 
  new G4Material("XenonGas", z=54., a=131.29*g/mole, density= 5.458*mg/cm3,
                 kStateGas, temperature= 293.15*kelvin, pressure= 1*atmosphere);
  // PLexi 
  G4Material* Plexi = man->FindOrBuildMaterial("G4_PLEXIGLASS");
  //G4Material* Plexi = Air;
  // Print all the materials defined.
  //
  G4cout << G4endl << "The materials defined are : " << G4endl << G4endl;
  G4cout << *(G4Material::GetMaterialTable()) << G4endl;

//--------- Sizes of the principal geometrical components (solids)  ---------
  
  NbOfChambers = 2;
  ChamberWidth = 2*cm;
  ChamberSpacing = 20*cm;
  
  fTrackerLength = (NbOfChambers+1)*ChamberSpacing; // Full length of Tracker
  fTargetLength  = 3.0 * cm;                        // Full length of Target
  
  TargetMater  = Pb;
  ChamberMater = Xenon;
  
  // fWorldLength= 10* cm;
  fWorldLength= 1.2*(fTargetLength+fTrackerLength);

   
  G4double targetSize  = 0.5*fTargetLength;    // Half length of the Target  
  G4double trackerSize = 0.5*fTrackerLength;   // Half length of the Tracker
      
//--------- Definitions of Solids, Logical Volumes, Physical Volumes ---------
  
  //------------------------------ 
  // World
  //------------------------------ 

  G4double HalfWorldLength = 0.5*fWorldLength;
 
  G4GeometryManager::GetInstance()->SetWorldMaximumExtent(fWorldLength);
  G4cout << "Computed tolerance = "
         << G4GeometryTolerance::GetInstance()->GetSurfaceTolerance()/mm
         << " mm" << G4endl;

  solidWorld= new G4Box("world",HalfWorldLength,HalfWorldLength,HalfWorldLength);
  logicWorld= new G4LogicalVolume( solidWorld, Air, "World", 0, 0, 0);
  
  //  Must place the World Physical volume unrotated at (0,0,0).
  // 
  physiWorld = new G4PVPlacement(0,               // no rotation
                                 G4ThreeVector(), // at (0,0,0)
                                 logicWorld,      // its logical volume
				 "World",         // its name
                                 0,               // its mother  volume
                                 false,           // no boolean operations
                                 0);              // copy number
				 
  //------------------------------ 
  // Target - detector
  //------------------------------
   
  //  G4ThreeVector positionTarget = G4ThreeVector(0,-180.,-(targetSize+trackerSize));
  
  G4ThreeVector positionTarget = G4ThreeVector(18.*cm,-(targetSize),0.);
     
  solidTarget = new G4Box("target",targetSize,targetSize,targetSize);
  logicTarget = new G4LogicalVolume(solidTarget,Pb,"Target",0,0,0);
  physiTarget = new G4PVPlacement(0,               // no rotation
				  positionTarget,  // at (x,y,z)
				  logicTarget,     // its logical volume		       	  
				  "Target",        // its name
				  logicWorld,      // its mother  volume
				  false,           // no boolean operations
				  0);              // copy number 

  G4cout << "Target is " << fTargetLength/cm << " cm of " 
         << TargetMater->GetName() << G4endl;
  
  //------------------------------ 
  // Tracker (used as shielding!)
  //------------------------------
  
  G4ThreeVector positionTracker = G4ThreeVector(10.*cm,-15.5*cm,0.);
  
  //  solidTracker = new G4Box("tracker",trackerSize,trackerSize,trackerSize); 
  solidTracker = new G4Box("tracker",2.*cm,15.*cm,5.*cm); 
  logicTracker = new G4LogicalVolume(solidTracker , Pb, "Tracker",0,0,0);  
  physiTracker = new G4PVPlacement(0,              // no rotation
				  positionTracker, // at (x,y,z)
				  logicTracker,    // its logical volume				  
				  "Tracker",       // its name
				  logicWorld,      // its mother  volume
				  false,           // no boolean operations
  				   0);
  
  //------------------------------ 
  // Slits detector 
  //------------------------------

  
  //G4ThreeVector positionSlit1 = G4ThreeVector((18.-5.05)*cm,.26*cm,0);//ouverture 1mm
  G4ThreeVector positionSlit1 = G4ThreeVector((18.-5.75)*cm,0.26*cm,0);

  solidSlit1 = new G4Box("slit1",5.*cm,0.2*cm,5.*cm); 
  logicSlit1 = new G4LogicalVolume(solidSlit1 , Plexi, "Slit1",0,0,0);  
  physiSlit1 = new G4PVPlacement(0,              // no rotation
				  positionSlit1, // at (x,y,z)
				  logicSlit1,    // its logical volume	  	  
				 "Slit1",       // its name
				  logicWorld,      // its mother  volume
				  false,           // no boolean operations
				   				  0);        
  
  //G4ThreeVector positionSlit2 = G4ThreeVector((18.+5.05)*cm,.26*cm,0);//ouverture 1 mm
  G4ThreeVector positionSlit2 = G4ThreeVector((18.+5.75)*cm,0.26*cm,0);

  solidSlit2 = new G4Box("slit2",5.*cm,0.2*cm,5.*cm); 
  logicSlit2 = new G4LogicalVolume(solidSlit2 , Plexi, "Slit2",0,0,0);  
  physiSlit2 = new G4PVPlacement(0,              // no rotation
				  positionSlit2, // at (x,y,z)
				  logicSlit2,    // its logical volume	  	  
				  "Slit2",       // its name
				  logicWorld,      // its mother  volume
				  false,           // no boolean operations
				   				  0);      
  		   				            
  /* 
 //------------------------------ 
  // source holder
  //------------------------------
       

  //  G4ThreeVector positionHolder = G4ThreeVector(0.,0.,0.);
  G4ThreeVector positionHolder = G4ThreeVector(-18.*cm,-33.17*cm,0.);

  solidHolder = new G4Box("holder",1.5*cm,0.35*cm,1.5*cm);    
  logicHolder = new G4LogicalVolume(solidHolder , Plexi, "Holder",0,0,0);  
  physiHolder = new G4PVPlacement(0,              // no rotation
				  positionHolder, // at (x,y,z)
				  logicHolder,    // its logical volume		
				  "Holder",       // its name
				  logicWorld,      // its mother  volume
				  false,           // no boolean operations
				  		  0);          

  
  //   G4ThreeVector positionHolder2 = G4ThreeVector(-18.*cm,-33.07*cm,0.);
  G4ThreeVector positionHolder2 = G4ThreeVector(0.*cm,-2*mm,0.);
 const G4double startAngleDisco = 0.*deg;
 const G4double spanningAngleDisco = 360.*deg;
 G4double phi = 90. *deg;   
 G4RotationMatrix rm;               
 rm.rotateX(phi);
  
 
 //solidHolder2 = new G4Tubs("holder2",0.*cm,0.25*cm,0.3*cm,startAngleDisco,spanningAngleDisco);    
solidHolder2 = new G4Tubs("holder2",0.,5*mm,0.5*mm,startAngleDisco,spanningAngleDisco);    

//  logicHolder2 = new G4LogicalVolume(solidHolder2 , Plexi, "Holder2",0,0,0);  
 logicHolder2 = new G4LogicalVolume(solidHolder2 ,Air, "Holder2",0,0,0);  
  physiHolder2 = new G4PVPlacement(G4Transform3D(rm, positionHolder2),
				  logicHolder2,    // its logical volume	
				   "Holder2",       // its name
				  logicHolder,      // its mother  volume
				  false,           // no boolean operations
				   0);

   
  // G4ThreeVector positionHolder3 = G4ThreeVector(-18.*cm,-32.795*cm,0.);
  
//   solidHolder3 = new G4Box("holder3",1.5*cm,0.05*cm,1.5*cm);    
//   logicHolder3 = new G4LogicalVolume(solidHolder3 , Plexi, "Holder3",0,0,0);  
//   physiHolder3 = new G4PVPlacement(0,              // no rotation
// 				  positionHolder3, // at (x,y,z)
// 				  logicHolder3,    // its logical volume				  
// 				  "Holder3",       // its name
// 				  logicWorld,      // its mother  volume
// 				  false,           // no boolean operations
// 				   				  0);          
  	

		   
 
  G4ThreeVector positionHolder4 = G4ThreeVector(0.*cm,1*mm,0.);
  // const G4double startAngleDisco = 0.*deg;
  //const G4double spanningAngleDisco = 360.*deg;
  //G4double phi = 90. *deg;   
  //G4RotationMatrix rm;               
  //rm.rotateX(phi);
  
  solidHolder4 = new G4Tubs("holder4",0.*cm,2.5*mm,2.5*mm,startAngleDisco,spanningAngleDisco); //diametre tube 5mm   
  //  solidHolder4 = new G4Tubs("holder4",0.*cm,1*mm,2.5*mm,startAngleDisco,spanningAngleDisco); //diametre tube 1mm   

 logicHolder4 = new G4LogicalVolume(solidHolder4 ,Air, "Holder4",0,0,0);  
  physiHolder4 = new G4PVPlacement(G4Transform3D(rm, positionHolder4),
				  logicHolder4,    // its logical volume	
				   "Holder4",       // its name
				  logicHolder,      // its mother  volume
				  false,           // no boolean operations
				   0);

*/  

 /*
 G4ThreeVector positionHolder5 = G4ThreeVector(-18.*cm,-32.42*cm,0.);
  // const G4double startAngleDisco = 0.*deg;
  //const G4double spanningAngleDisco = 360.*deg;
  //G4double phi = 90. *deg;   
  //G4RotationMatrix rm;               
  //rm.rotateX(phi);
  
solidHolder5 = new G4Tubs("holder5",2.5*mm,0.75*cm,3*mm,startAngleDisco,spanningAngleDisco);    

 logicHolder5 = new G4LogicalVolume(solidHolder5 ,Plexi, "Holder5",0,0,0);  
  physiHolder5 = new G4PVPlacement(G4Transform3D(rm, positionHolder5),
				  logicHolder5,    // its logical volume	
				   "Holder2",       // its name
				  logicWorld,      // its mother  volume
				  false,           // no boolean operations
				   0);


  */

    // copy number 
  
  //------------------------------ 
  // Tracker segments
  //------------------------------
  // 
  // An example of Parameterised volumes
  // dummy values for G4Box -- modified by parameterised volume
  /*
  solidChamber = new G4Box("chamber", 100*cm, 100*cm, 10*cm); 
  logicChamber = new G4LogicalVolume(solidChamber,Air,"Chamber",0,0,0);
  
  G4double firstPosition = -trackerSize + 0.5*ChamberWidth;
  G4double firstLength = fTrackerLength/10;
  G4double lastLength  = fTrackerLength;
   
  chamberParam = new ExN02ChamberParameterisation(  
			   1,          // NoChambers 
			   firstPosition,         // Z of center of first 
			   ChamberSpacing,        // Z spacing of centers
			   ChamberWidth,          // Width Chamber 
			   firstLength,           // lengthInitial 
			   lastLength);           // lengthFinal
			   
  // dummy value : kZAxis -- modified by parameterised volume
  //
  physiChamber = new G4PVParameterised(
                            "Chamber",       // their name
                            logicChamber,    // their logical volume
                            logicTracker,    // Mother logical volume
			    kZAxis,          // Are placed along this axis 
                          1,    // Number of chambers
                            chamberParam);   // The parametrisation

  G4cout << "There are " << NbOfChambers << " chambers in the tracker region. "
         << "The chambers are " << ChamberWidth/mm << " mm of " 
         << ChamberMater->GetName() << "\n The distance between chamber is "
	 << ChamberSpacing/cm << " cm" << G4endl;
  */ 	 
  //------------------------------------------------ 
  // Sensitive detectors
  //------------------------------------------------ 

  G4SDManager* SDman = G4SDManager::GetSDMpointer();

  G4String trackerChamberSDname = "ExN02/TrackerChamberSD";
  ExN02TrackerSD* aTrackerSD = new ExN02TrackerSD( trackerChamberSDname );
  SDman->AddNewDetector( aTrackerSD );
  //logicChamber->SetSensitiveDetector( aTrackerSD );
  //logicTracker->SetSensitiveDetector( aTrackerSD );
  //logicHolder->SetSensitiveDetector( aTrackerSD );
  //logicHolder2->SetSensitiveDetector( aTrackerSD );
  //logicSlit1->SetSensitiveDetector( aTrackerSD );
  //  logicWorld->SetSensitiveDetector( aTrackerSD );

//--------- Visualization attributes -------------------------------

  G4VisAttributes* BoxVisAtt= new G4VisAttributes(G4Colour(1.0,1.0,1.0));
  logicWorld  ->SetVisAttributes(BoxVisAtt);  
  //logicTarget ->SetVisAttributes(BoxVisAtt);
  // logicTracker->SetVisAttributes(BoxVisAtt);
  
  G4VisAttributes* ChamberVisAtt = new G4VisAttributes(G4Colour(1.0,1.0,0.0));
// logicHolder->SetVisAttributes(ChamberVisAtt);
  //logicHolder2->SetVisAttributes(ChamberVisAtt);
  //logicSlit1->SetVisAttributes(ChamberVisAtt);
  
//--------- example of User Limits -------------------------------

  // below is an example of how to set tracking constraints in a given
  // logical volume(see also in N02PhysicsList how to setup the processes
  // G4StepLimiter or G4UserSpecialCuts).
    
  // Sets a max Step length in the tracker region, with G4StepLimiter
  //
  //G4double maxStep = 0.5*ChamberWidth;
  G4double maxStep = 5.*mm;
  stepLimit = new G4UserLimits(maxStep);
  //logicTracker->SetUserLimits(stepLimit);
  logicWorld->SetUserLimits(stepLimit);
  
  // Set additional contraints on the track, with G4UserSpecialCuts
  //
  //G4double maxLength = 100*cm, maxTime = 0.1*s, minEkin = 100*eV;
   //logicWorld->SetUserLimits(new G4UserLimits(maxStep,maxLength,maxTime,minEkin));

  //SetMagField(0.00001);



//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
 #if FIELD
  G4double Fieldvalue, Momentum, kine;
  G4double m_e = 510.998910;

  std::ifstream fieldfile("test.txt");
  fieldfile >> kine ;
  G4cout << "Kinetic energy read from test.txt: " << kine << G4endl; 

  BINKINE= kine;  // saved in global variable

  Momentum = sqrt((kine+m_e)*(kine+m_e)-m_e*m_e);
  //Momentum = sqrt((kine+25.+m_e)*(kine+25.+m_e)-m_e*m_e);

  //defining this in this way, the units are: B[T], r[m] and momentum = pc =[Mev], but the momentun is in KeV, so I divide by 1000
  Fieldvalue = Momentum/(1000.*0.299792458*0.18);
  static G4bool fieldIsInitialized = false;
  
  G4double kine_new = -2.; 

  if(!fieldIsInitialized)
    {
      G4FieldManager   *pFieldMgr;
      //G4FieldManager*    fLocalFieldManager ;
      G4double Fval = 0.0185185185; //initial only, overwritten later
      G4double step = Fval/1000.; 
      //Fval -= 0*step;
      //Fval = Fieldvalue/1000.-Fieldvalue/1000.*0.0025;
      //Here I divide by 1000 so the momentum is correctly given in keV
      Fval = Fieldvalue/1000;
      //G4MagneticField* MField= new ExN02MagneticField("BFIELD_all_test.txt","BFIELD_out_test.txt",Fval);
      //G4MagneticField* MField= new ExN02MagneticField("BFIELD_all_cut.txt","BFIELD_out_cut.txt",Fval);
      //G4MagneticField* MField = new ExN02MagneticField("BFIELD_all_200.txt","BFIELD_out_200.txt",Fval, kine_new);
      ExN02NewMagneticField* MField = new ExN02NewMagneticField(Fval);
      //Here some changes will be made. If an extra argument has been provided and passed, then the kinetic energy is put in here. 
      //If not, then use standard value from test.txt. 
      //G4cout << "Field read from variable: " << MField.fKineticEnergy << G4endl; 

   
      //FieldTesla = Fval;  // save the filed value for analysis

       pFieldMgr=G4TransportationManager::GetTransportationManager()->GetFieldManager();
       //pFieldMgr->SetDeltaOneStep(1.*mm); 
       pFieldMgr->SetMinimumEpsilonStep(20.*mm); 


      //fLocalFieldManager = new G4FieldManager();

       //G4Mag_UsualEqRhs* MyEquationEF3 = new G4Mag_usualEqRhs(MField);

       /*
      
       G4EqMagElectricField *myEquationEF3 = new G4EqMagElectricField(MField);
       //G4EqMagElectricField *LocalEquationEF3 = new G4EqMagElectricField(MLocalField);
       G4MagIntegratorStepper* myStepperEF3 = new G4ClassicalRK4(myEquationEF3);
       //G4MagIntegratorStepper* LocalStepperEF3 = new G4ClassicalRK4(LocalEquationEF3,8);
       //G4MagIntegratorStepper* myStepperEF3 = new G4SimpleHeum(myEquationEF3,8);
       //G4MagIntegratorStepper* myStepperEF3 = new G4SimpleRunge(myEquationEF3,8);
       //G4MagIntegratorStepper* myStepperEF3 = new G4ImplicitEuler(myEquationEF3,8);
       //G4MagIntegratorStepper* myStepperEF3 = new G4ExplicitEuler(myEquationEF3,8);
       //G4MagIntegratorStepper* LocalStepperEF3 = new G4ExplicitEuler(LocalEquationEF3,8);
       //G4MagIntegratorStepper* myStepperEF3 = new G4CashKarpRKF45(myEquationEF3);

       //  G4cout << "******************** 3 ***********************" << endl;
       G4MagInt_Driver* myIntgrDriverEF3 = new G4MagInt_Driver(0.0001*cm,myStepperEF3,
                                            myStepperEF3->GetNumberOfVariables()); 
       //G4MagInt_Driver* LocalIntgrDriverEF3 = new G4MagInt_Driver(0.1*cm,LocalStepperEF3,
       //                                   LocalStepperEF3->GetNumberOfVariables()); 
  

       G4ChordFinder* myChordFinderEF3 = new G4ChordFinder(myIntgrDriverEF3);
       //G4ChordFinder* LocalChordFinderEF3 = new G4ChordFinder(LocalIntgrDriverEF3);

       pFieldMgr->SetChordFinder(myChordFinderEF3);
       //fLocalFieldManager->SetChordFinder(LocalChordFinderEF3);

       */
      pFieldMgr->SetDetectorField(MField);      
      pFieldMgr->CreateChordFinder(MField);


      //       G4ChordFinder* myChordFinderEF3 = new G4ChordFinder(MField,1.0*mm,0);
      // pFieldMgr->SetChordFinder(myChordFinderEF3);
 

      G4bool allLocal = true ;
      //  logicWorld->SetFieldManager(pFieldMgr,allLocal);
      // logicTracker->SetFieldManager(fLocalFieldManager,allLocal);
      


      
      fieldIsInitialized = true;

      /*


       */
       }
#endif


  return physiWorld;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
 
void ExN02DetectorConstruction::setTargetMaterial(G4String materialName)
{
  // search the material by its name 
  G4Material* pttoMaterial = G4Material::GetMaterial(materialName);  
  if (pttoMaterial)
     {TargetMater = pttoMaterial;
      logicTarget->SetMaterial(pttoMaterial); 
      G4cout << "\n----> The target is " << fTargetLength/cm << " cm of "
             << materialName << G4endl;
     }             
}
 
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ExN02DetectorConstruction::setChamberMaterial(G4String materialName)
{
  // search the material by its name 
  G4Material* pttoMaterial = G4Material::GetMaterial(materialName);  
  if (pttoMaterial)
     {ChamberMater = pttoMaterial;
      logicChamber->SetMaterial(pttoMaterial); 
      G4cout << "\n----> The chambers are " << ChamberWidth/cm << " cm of "
             << materialName << G4endl;
     }             
}
 
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
/*
void ExN02DetectorConstruction::SetMagField(G4double fieldValue)
{
  fpMagField->SetMagFieldValue(fieldValue);  
}
*/
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ExN02DetectorConstruction::SetMaxStep(G4double maxStep)
{
  if ((stepLimit)&&(maxStep>0.)) stepLimit->SetMaxAllowedStep(maxStep);
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
