#include <iostream>
#include <fstream>

using namespace std; 

int main() {


	std::ofstream ofs ("SB_sim_min_runner.sh", std::ofstream::out);

	//What do we need to do with commands?
	//-Remove old test.txt file
	//Make new one with correct energy	"echo <value> > test.txt"
	//run geant thinger
	//rename root file

	int N_iter = 40; 
	double E_start = 200.; 
	double E_step = 20.; 

	int E_value = 0; 

	for(int i=0; i<N_iter; i++)
	{

		E_value = int(E_start + i*E_step); 

		ofs << "rm test.txt" << endl; 
		ofs << "echo " << E_value << " > test.txt" << endl; 
		ofs << "./exampleN02 run2.mac" << endl; 
		ofs << "mv ExN02.root ExN02_" << E_value << "keV.root" << endl; 
		ofs << endl; 
	}

    
    return 0;
}