rm test.txt
echo 200 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_200keV.root

rm test.txt
echo 220 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_220keV.root

rm test.txt
echo 240 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_240keV.root

rm test.txt
echo 260 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_260keV.root

rm test.txt
echo 280 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_280keV.root

rm test.txt
echo 300 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_300keV.root

rm test.txt
echo 320 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_320keV.root

rm test.txt
echo 340 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_340keV.root

rm test.txt
echo 360 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_360keV.root

rm test.txt
echo 380 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_380keV.root

rm test.txt
echo 400 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_400keV.root

rm test.txt
echo 420 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_420keV.root

rm test.txt
echo 440 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_440keV.root

rm test.txt
echo 460 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_460keV.root

rm test.txt
echo 480 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_480keV.root

rm test.txt
echo 500 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_500keV.root

rm test.txt
echo 520 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_520keV.root

rm test.txt
echo 540 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_540keV.root

rm test.txt
echo 560 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_560keV.root

rm test.txt
echo 580 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_580keV.root

rm test.txt
echo 600 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_600keV.root

rm test.txt
echo 620 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_620keV.root

rm test.txt
echo 640 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_640keV.root

rm test.txt
echo 660 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_660keV.root

rm test.txt
echo 680 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_680keV.root

rm test.txt
echo 700 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_700keV.root

rm test.txt
echo 720 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_720keV.root

rm test.txt
echo 740 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_740keV.root

rm test.txt
echo 760 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_760keV.root

rm test.txt
echo 780 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_780keV.root

rm test.txt
echo 800 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_800keV.root

rm test.txt
echo 820 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_820keV.root

rm test.txt
echo 840 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_840keV.root

rm test.txt
echo 860 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_860keV.root

rm test.txt
echo 880 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_880keV.root

rm test.txt
echo 900 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_900keV.root

rm test.txt
echo 920 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_920keV.root

rm test.txt
echo 940 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_940keV.root

rm test.txt
echo 960 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_960keV.root

rm test.txt
echo 980 > test.txt
./exampleN02 run2.mac
mv ExN02.root ExN02_980keV.root

