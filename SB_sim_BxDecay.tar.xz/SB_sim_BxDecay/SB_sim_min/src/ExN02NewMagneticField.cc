


#include "G4UniformElectricField.hh"
#include "G4UniformMagField.hh"
#include "G4MagneticField.hh"
#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"
#include "G4EquationOfMotion.hh"
#include "G4EqMagElectricField.hh"
#include "G4Mag_UsualEqRhs.hh"
#include "G4MagIntegratorStepper.hh"
#include "G4MagIntegratorDriver.hh"
#include "G4ChordFinder.hh"

#include "G4ExplicitEuler.hh"
#include "G4ImplicitEuler.hh"
#include "G4SimpleRunge.hh"
#include "G4SimpleHeum.hh"
#include "G4ClassicalRK4.hh"
#include "G4HelixExplicitEuler.hh"
#include "G4HelixImplicitEuler.hh"
#include "G4HelixSimpleRunge.hh"
#include "G4CashKarpRKF45.hh"
#include "G4RKG3_Stepper.hh"
#include "G4SystemOfUnits.hh"

#include "ExN02NewMagneticField.hh"

//#define FIELD 0
//The value that we give must be in gauss units (see detector construction part Diego to see how I did it)
ExN02NewMagneticField::ExN02NewMagneticField(G4double B_ref) : Bvalue_ref(B_ref)
{    
 
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
void ExN02NewMagneticField::GetFieldValue(const double point[4],
				      double *Mfield ) const
{

  double fieldUnit = tesla;     
  double x = point[0];
  double y = point[1];
  double z = point[2];
  
  double RR = sqrt(x*x+y*y);
  double ZZ = z;
  bool in = true;
  double B0 = Bvalue_ref*fieldUnit;
  double r0 = 18*cm;
  double val1 = (RR-r0)/r0;

  if(y>0.){

    //Bx
    Mfield[1] = -y*z*B0/(RR*0.5*r0)*(val1-1); 
    //By
    Mfield[0] = x*z*B0/(RR*0.5*r0)*(val1-1); 
    //Bz
    Mfield[2] = -B0*((1-0.5*val1)+0.25*(val1*val1));

  }
  else{

    //Bx
  Mfield[0] = B0*0.; 
  //By
  Mfield[1] = B0*0.;
  //Bz
  Mfield[2] = B0*0.;
  }

  //G4cout << "The value of the magnetic field B is" << B0 << G4endl;

  
 
  
    
  
  // G4cout << "  R "  <<  R[38] << " Z " << Z[38][6] <<  endl;
  /*
  if (indexR>-1&&indexZ>-1)
    {
      G4cout << "  A la position (cm): "  <<  x/cm << "  " << y/cm  << "  " << z/cm  << "  " << " r: " << RR/cm   << endl;
      G4cout << "  Le champ vaut [Volt/cm] : "  <<  Efield[0]/(volt/cm) << "  " << Efield[1]/(volt/cm) << "  " << Efield[2]/(volt/cm) << "  " << endl;
      G4cout << "  Le champ vaut : "  <<  Ez/(volt/cm) << "  " << Er/(volt/cm) <<  endl;
      G4cout << "  indexZ: "  <<  indexZ << " indexR " << indexR <<  endl;
      G4cout << " mm " << mm << G4endl;
      }
  */
}

