//
// ********************************************************************
// * License and Disclaimer                                           *
// *                                                                  *
// * The  Geant4 software  is  copyright of the Copyright Holders  of *
// * the Geant4 Collaboration.  It is provided  under  the terms  and *
// * conditions of the Geant4 Software License,  included in the file *
// * LICENSE and available at  http://cern.ch/geant4/license .  These *
// * include a list of copyright holders.                             *
// *                                                                  *
// * Neither the authors of this software system, nor their employing *
// * institutes,nor the agencies providing financial support for this *
// * work  make  any representation or  warranty, express or implied, *
// * regarding  this  software system or assume any liability for its *
// * use.  Please see the license in the file  LICENSE  and URL above *
// * for the full disclaimer and the limitation of liability.         *
// *                                                                  *
// * This  code  implementation is the result of  the  scientific and *
// * technical work of the GEANT4 collaboration.                      *
// * By using,  copying,  modifying or  distributing the software (or *
// * any work based  on the software)  you  agree  to acknowledge its *
// * use  in  resulting  scientific  publications,  and indicate your *
// * acceptance of all terms of the Geant4 Software license.          *
// ********************************************************************
//
//
// $Id: ExN02SteppingAction.cc,v 1.9 2006-06-29 17:48:18 gunter Exp $
// GEANT4 tag $Name: not supported by cvs2svn $
// 
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

#include "ExN02SteppingAction.hh"
#include "G4SteppingManager.hh"
#include "ExN02Analysis.hh"

#include "G4TrackVector.hh"
#include "G4ios.hh"
#include "G4SteppingManager.hh"
#include "G4Track.hh"
#include "G4Step.hh"
#include "G4StepPoint.hh"
#include "G4TrackStatus.hh"
#include "G4TrackVector.hh"
#include "G4ParticleDefinition.hh"
#include "G4ParticleTypes.hh"
#include "G4UserEventAction.hh" 
#include "Global.h"

#include <vector>
#include <stack>
#include <valarray>
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
std::ofstream myfile("energy_det.txt");

ExN02SteppingAction::ExN02SteppingAction(ExN02Analysis* analysis)
  :ExN02analysis(analysis)
{ }

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......

void ExN02SteppingAction::UserSteppingAction(const G4Step* aStep)
{ 

  G4ThreeVector Vpos, Vmom;
  G4double valmomP, kineP;
  G4double Px,Py,Pz;
  G4double m_e = 0.510998910;


  //  G4int evtold;  //declarer en variable global
  //Event ID
  G4int  iEvt = G4EventManager::GetEventManager()->GetConstCurrentEvent()->GetEventID();

  if (evtold!=iEvt)
   {
     traX.clear();
     traY.clear(); 
     traZ.clear();
     traPY.clear();
     kinetic.clear();
     evtold = iEvt;
   }

  // momentum of primary particle at source position  
  // It seems the prim. vertex is filled only with the first track in sch2cpp so this is valid only for the case where there is one particle generated!!!
  G4ThreeVector valmom = G4EventManager::GetEventManager()->GetConstCurrentEvent()->GetPrimaryVertex(0)->GetPrimary(0)->GetMomentum();
  valmomP = sqrt(valmom.x()*valmom.x()+valmom.y()*valmom.y()+valmom.z()*valmom.z());
  
  G4int numberP =  G4EventManager::GetEventManager()->GetConstCurrentEvent()->GetPrimaryVertex(0)->GetNumberOfParticle();
  // kinetic energy of particle at source position - not used see comments above
  kineP = (sqrt(valmomP*valmomP+m_e*m_e)-m_e);
 
  G4int sid = aStep->GetTrack()->GetCurrentStepNumber();
  G4int pid = aStep->GetTrack()->GetParticleDefinition()->GetPDGEncoding();

  G4int tid = aStep->GetTrack()->GetTrackID();
  G4int parent_ID = aStep->GetTrack()->GetParentID();

  //G4cout << aStep->GetTrack()->GetDefinition()->GetParticleName() << "\t" << aStep->GetPreStepPoint()->GetPosition().x() << "\t" << aStep->GetPreStepPoint()->GetPosition().y() << "\t" << aStep->GetPreStepPoint()->GetPosition().z() << G4endl; 


    // G4cout << numberP << " " << valmomP << " "  << sid << G4endl;

  G4ParticleDefinition *def = aStep->GetTrack()->GetDefinition();

 G4double posX = aStep->GetTrack()->GetPosition().x() / cm;
 G4double posY = aStep->GetTrack()->GetPosition().y() / cm;
 G4double posZ = aStep->GetTrack()->GetPosition().z() / cm;
 G4ThreeVector pos =  aStep->GetTrack()->GetPosition();
 G4ThreeVector ParticleMomentum =  aStep->GetTrack()->GetMomentum();
 G4ThreeVector ParticleMomentum2 = aStep->GetPreStepPoint()->GetMomentum();
 int pdg = def->GetPDGEncoding();
 int charge = def->GetPDGCharge();


 //M van Dijk

 //G4double preposy = aStep->GetPreStepPoint()->GetPosition().y(); 
 //G4double postposy = aStep->GetTrack()->GetPostStepPoint()->GetPosition().y(); 

 //if(preposy <0 && postposy > 0)
 //{
 //   G4cout << "found one" << G4endl;
 //}

 //End M van Dijk


 Vpos = aStep->GetTrack()->GetVertexPosition();
 Vmom = aStep->GetTrack()->GetVertexMomentumDirection();

 G4double Mom = sqrt(ParticleMomentum2.x()*ParticleMomentum2.x()+ParticleMomentum2.y()*ParticleMomentum2.y()+ParticleMomentum2.z()*ParticleMomentum2.z());
 
 if (Mom<0.01) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
 //if (posX>0&&posY>-3) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);

 // Get the momentum at the first step (close to generated position in order to have the initial energy (almost)
 if (sid==1)
   {
     MomIni = (sqrt(Mom*Mom+m_e*m_e)-m_e); //c'est l'energie cinetique ici!!! 
     VposIni = pos;
     VmomIni = ParticleMomentum;

     //Diego: try to kill all traks after the first step because I only want the generation spectrum
     /*if (aStep->GetTrack()->GetParticleDefinition()->GetPDGEncoding() == 22){

        aStep->GetTrack()->SetTrackStatus(fStopAndKill);
        G4cout << "gamma step 0" << G4endl;
      }

      //Diego: Keep the information to the tree

      G4int Part_ID = aStep->GetTrack()->GetParticleDefinition()->GetPDGEncoding();
      G4int Track_ID = aStep->GetTrack()->GetTrackID();
      G4double Ener = aStep->GetTrack()->GetKineticEnergy();

      ExN02analysis->setNtuple2(0, Track_ID, Part_ID, Ener);
      */



   }

   if (aStep->GetTrack()->GetCurrentStepNumber()==1 && aStep->GetTrack()->GetParticleDefinition()->GetPDGEncoding() == 22){

      aStep->GetTrack()->SetTrackStatus(fStopAndKill);
   }

  /*const G4ThreeVector& vect = G4ThreeVector(-18.*cm,-32.*cm,0.);
  if (aStep->GetPreStepPoint()->GetPosition() == vect) 
  { 
    
    if (step->GetTrack()->GetParentID() == 1)
    {
      if (step->GetTrack()->GetDefinition()->GetPDGEncoding() == 11)
      {
    //Here I only obtain some information, fill the TTree and print info: TID: Track ID, PID: Particle ID
    G4double energy = aStep->GetTrack()->GetKineticEnergy();
    G4int Part_ID = aStep->GetTrack()->GetDefinition()->GetPDGEncoding();
    G4int Track_ID = aStep->GetTrack()->GetTrackID();
    G4int ev = 0;
        //G4cout << "Electron produced at the origin" << G4endl;
        //G4cout << "Kinetic energy: " << energy << G4endl;
        //G4cout << "Processss: " << step->GetTrack()->GetCreatorProcess()->GetProcessName() << G4endl;
    ExN02analysis->setNtuple2(ev,Track_ID, Part_ID, energy);

    if (aStep->GetTrack()->GetDefinition()->GetPDGEncoding() == 22) aStep->GetTrack()->SetTrackStatus(fStopAndKill);


  }*/
    
  //Finish: Diego 

 //Get the momentum and position at the first step of the current track
if (tid!=tidold)
   {
     tidold= tid;
     //VposIni = pos;
     //VmomIni = ParticleMomentum;

   }
// position w.r.t the  detector - R = 0 is detector center
 G4double R = sqrt((posX-18.)*(posX-18.)+posZ*posZ);
 G4double RR = sqrt((posX)*(posX)+posY*posY);
 G4double kin = sqrt(Mom*Mom+m_e*m_e)-m_e;
 Px = ParticleMomentum2.x();
 Py = ParticleMomentum2.y();
 Pz = ParticleMomentum2.z();

 G4double en = aStep->GetTotalEnergyDeposit();

 //G4cout << kin << " " << en << " " <<kin+ en  << " " << posY <<G4endl; 

 // to get the trajectory coordinates 
 traX.push_back(posX);
 traY.push_back(posY);
 traZ.push_back(posZ);
 traPY.push_back(Py);
 kinetic.push_back(kin);

      // if (fabs(posX-18.)<2&&posY<1&&posY>0&&evtold!=iEvt)
 //  if (evtold!=iEvt)
 //{
     // myfile << MomIni << std::endl;
 //  evtold = iEvt;

 //}


 // if (posY>1.55) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
 //if (posY<-0.5) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);

 //if (posY>0.&&fabs(RR-18)>3&&posZ>2) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
  
  if (posY<-10.&&fabs(posX-18)<2) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
 
  //  if (RR<15.) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
  //  if(RR>22.) aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);
 

  // if (posY>1.5&&fabs(posX)<1.&&fabs(posZ)<1.) 
  if (posY<-0.000001&&fabs(posX-18.)<2.&&fabs(posZ)<5.)
  {
    aStep->GetTrack()->SetTrackStatus(fKillTrackAndSecondaries);  

    //G4cout << MomIni << " " << kin << " " << posX << G4endl;  
    ExN02analysis->setNtuple1(pos,ParticleMomentum2,iEvt,MomIni,BINKINE,VposIni,VmomIni, pid, tid, parent_ID);
    
    if (VmomIni.y()<0) 
    {
    // G4cout << MomIni << " " << iEvt << " " << kin << " " << en << G4endl;
      for (int ijk=0; ijk<traX.size(); ijk++)
      {
        G4cout << traX[ijk] << " " << traY[ijk] << " " << traZ[ijk] << " " << " " << traPY[ijk]   << " " << kinetic[ijk] <<G4endl;

      }
    }
  }
 
}
