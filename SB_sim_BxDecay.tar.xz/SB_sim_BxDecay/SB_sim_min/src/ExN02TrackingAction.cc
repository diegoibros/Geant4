#include "ExN02TrackingAction.hh"

// Geant4:
#include "G4Track.hh"
#include "G4ParticleTypes.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include "ExN02Analysis.hh"
#include "G4ThreeVector.hh"

// This project:

#include "ExN02EventAction.hh"

ExN02TrackingAction::ExN02TrackingAction(ExN02EventAction* EA, ExN02Analysis* anal)
  : G4UserTrackingAction(),
    fEvent(EA), analysis(anal)
{
  return;
}

ExN02TrackingAction::~ExN02TrackingAction()
{
  return;
}

void ExN02TrackingAction::PreUserTrackingAction(const G4Track * track)
{
  
  
  G4int TID = track->GetTrackID();
  G4int PID = track->GetParticleDefinition()->GetPDGEncoding();
  G4double Ekin = track->GetKineticEnergy();
  G4ThreeVector Pini = track->GetMomentumDirection();

  analysis->setNtuple2(0,TID, PID, Ekin, Pini);

  /*G4cout << "[debug] TrackingAction::PreUserTrackingAction: Track ID #" << TID << '\n';
  G4cout << "[debug] TrackingAction::PreUserTrackingAction:   PID   = '" << PID << '\n';
  
  G4cout << "[debug] TrackingAction::PreUserTrackingAction:   Ekin   = " << Ekin << " (keV)" << '\n';*/

//  if (PID == 22) track->SetTrackStatus(fStopAndKill);
  
  

  return;
}

void ExN02TrackingAction::PostUserTrackingAction(const G4Track*)
{
  return;
}