
#ifdef GLOBAL
#define Global
#else
#define Global extern
#endif

Global int BINKINE;
Global int evtold;
Global int tidold;
Global G4ThreeVector VposIni, VmomIni;
