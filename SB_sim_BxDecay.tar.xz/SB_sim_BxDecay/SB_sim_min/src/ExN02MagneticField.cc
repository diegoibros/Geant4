


//#include "G4UniformElectricField.hh"
//#include "G4UniformMagField.hh"
#include "G4MagneticField.hh"
#include "G4ElectricField.hh"
#include "G4FieldManager.hh"
#include "G4TransportationManager.hh"
#include "G4EquationOfMotion.hh"
#include "G4EqMagElectricField.hh"
#include "G4Mag_UsualEqRhs.hh"
#include "G4MagIntegratorStepper.hh"
#include "G4MagIntegratorDriver.hh"
#include "G4ChordFinder.hh"

#include "G4ExplicitEuler.hh"
#include "G4ImplicitEuler.hh"
#include "G4SimpleRunge.hh"
#include "G4SimpleHeum.hh"
#include "G4ClassicalRK4.hh"
#include "G4HelixExplicitEuler.hh"
#include "G4HelixImplicitEuler.hh"
#include "G4HelixSimpleRunge.hh"
#include "G4CashKarpRKF45.hh"
#include "G4RKG3_Stepper.hh"

#include "ExN02MagneticField.hh"
#include "G4SystemOfUnits.hh"

ExN02MagneticField::ExN02MagneticField(const char* filename,const char* filename2, const double val, const G4double kine_new)
{    
 
  MagVal = val  ;
  
  //new part to read field from a grid (31.01.2013) 
  
  double lenUnit= m;
  double fieldUnit= tesla/1000000.;     
  G4cout << "\n ---> " "Reading the field grid from " << filename << " ... " << endl; 

  double x,y,z,By,Bx,Bz;
  double R,xx,yy;
  int i,j,k;
  ifstream file( filename ); // Open the file for reading.
  int inc= 0;
  //#define DEBUG

  char buffer[256];
  //read values x y z Bx By Bz
  for (k=0;k<17;k++)
      //for (k=0;k<33;k++)
    {
      Z[k] = (-0.04+0.005*k)*1000.;
       //Z[k] = (-0.04+0.0025*k)*1000.;
      for (j=0;j<51;j++)
      //for (j=0;j<101;j++)
	{
	  Y[j] = (0.005*j)*1000.;
	  //Y[j] = (0.0025*j)*1000.;
	  for (i=0;i<101;i++)
	  //  for (i=0;i<201;i++)
	    {
	      file.getline(buffer,256);
	      file >> x>> y>>z>>Bx >>By>>Bz;
	    
	      X[i] = x*1000.;
	      
	      // MAGFieldX[inc] = Bx/(1000.*0.965);
// 	      MAGFieldY[inc] = By/(1000.*0.965);
// 	      MAGFieldZ[inc] = Bz/(1000.*0.965);
	      
	      MAGFieldX[inc] = Bx/(1000.*0.966);
	      MAGFieldY[inc] = By/(1000.*0.966);
	      MAGFieldZ[inc] = Bz/(1000.*0.966);
	      inc++;
	    }
	}
    }
  file.close();
  //G4cout<< MAGFieldX[0] <<" " << MAGFieldX[87566]<< " " << MAGFieldZ[0] << " " << MAGFieldZ[87566]  << " " << X[0] << " " << Z[0] << endl;
 
  
 inc =0;
  ifstream file2( filename2 ); // Open the file for reading.
  for (k=0;k<17;k++)
  //for (k=0;k<33;k++)
    {
      Z[k] = (-0.04+0.005*k)*1000.;
      //Z[k] = (-0.04+0.0025*k)*1000.;
      for (j=0;j<29;j++)
      //for (j=0;j<61;j++)
	{
	  YY[j] = -(0.005*j)*1000.;
	  // YY[j] = -(0.0025*j)*1000.;
	  for (i=0;i<101;i++)
	    //  for (i=0;i<201;i++)
	    {
	      file2.getline(buffer,256);
	      file2 >> x>> y>>z>>Bx >>By>>Bz;
	    
	      X[i] = x*1000.;
	
	
	      MAGFieldXO[inc] = Bx/(1000.*0.965);
	      MAGFieldYO[inc] = By/(1000.*0.965);
	      MAGFieldZO[inc] = Bz/(1000.*0.965);


// 	      MAGFieldXO[inc] = Bx/(1000.*1.005);
// 	      MAGFieldYO[inc] = By/(1000.*1.005);
// 	      MAGFieldZO[inc] = Bz/(1000.*1.005);

	      inc++;
	    }
	}
    }

  file2.close();
  G4cout << "Reading complete." << G4endl;
}



//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo......
void ExN02MagneticField::GetFieldValue(const double point[4],
				      double *Bfield ) const
{

  double fieldUnit= tesla;     
 
  double x = point[0];
  double y = point[1];
  double z = point[2];
    
  double RR = sqrt(x*x+y*y);
  bool in = true;
  double B0 = MagVal*fieldUnit  ;
  double r0 = 18.*cm;
  double val1 = (RR-r0)/r0;
  int indexX(-1),indexY(-1),indexZ(-1);
  int i,j,k;
  //double corr = 0.066;  
  double corr = 0.069;  
  /*
  Bfield[0] = -x*z*B0/(RR*0.5*r0)*(val1-1); 
  Bfield[1] = -y*z*B0/(RR*0.5*r0)*(val1-1); 
  Bfield[2] = -B0*((1-0.5*val1)+0.25*(val1*val1)); 
  
    if(point[1]<0.)
   {
      Bfield[0] =  0.;
      Bfield[1] = 0.; 
      Bfield[2] =  0. ;
       }

  */       
  //G4cout << "1: " << Bfield[0] << " " << Bfield[1] << " " << Bfield[2] << endl;
  //  G4cout << "position: " << x << " " << y << " " << z<< endl;

  Bfield[0] =  0.;
  Bfield[1] = 0.; 
  Bfield[2] =  0. ;

         
 // search indices for closest neighbours
  if(x>-250&&x<250&&y>0&&y<250&&z>-40&&z<40)
    {
      for (k=0;k<17;k++)
      //for (k=0;k<33;k++)
	{
	  if(z<=Z[k+1]&&z>=Z[k]) indexZ = k;
	}
      for (j=0;j<51;j++)
      //for (j=0;j<101;j++)
	{
	  if(y<=Y[j+1]&&y>=Y[j]) indexY = j;
	}
       for (i=0;i<101;i++)
      //  for (i=0;i<201;i++)
	{
	  if(x<=X[i+1]&&x>=X[i]) indexX = i;  
	}
       // G4cout << x << " " << indexX<< " "  << X[indexX] << " " << y << " " <<indexY<< " "  << Y[indexY]<< " " << z << " " << indexZ<< " " << Z[indexZ]<<endl;

	 
    }

 


  // shortest distance finding

  double Dst[2][2][2];
  double dx, dy, dz;
  double distold =1000.;
  int FindexX,FindexY,FindexZ;
  int IndFin;
  double weight; 
  double Wmoy(0.), SWeight;


//Trilinear interpolation
 double xd,yd,zd;
 double C00x,C01x,C10x,C11x;
 double C00y,C01y,C10y,C11y;
 double C00z,C01z,C10z,C11z;
 double C0x,C0y,C0z,C1x,C1y,C1z;
 double Cx,Cy,Cz;
 int ind0, ind1; 
 if(x>-250.&&x<250.&&y>0.&&y<250.&&z>-40.&&z<40.)
   {
     xd= (x-X[indexX])/(X[indexX+1]-X[indexX]);
     yd= (y-Y[indexY])/(Y[indexY+1]-Y[indexY]);
     zd= (z-Z[indexZ])/(Z[indexZ+1]-Z[indexZ]);


     //interpolation along X

     ind0=   5151*indexZ+101*indexY+indexX;
     ind1=   5151*indexZ+101*indexY+indexX+1;
     //ind0=   20301*indexZ+201*indexY+indexX;
     //ind1=   20301*indexZ+201*indexY+indexX+1;
     C00x= MAGFieldX[ind0]*(1-xd)+MAGFieldX[ind1]*xd;
     C00y= MAGFieldY[ind0]*(1-xd)+MAGFieldY[ind1]*xd;
     C00z= MAGFieldZ[ind0]*(1-xd)+MAGFieldZ[ind1]*xd;

     ind0=   5151*indexZ+101*(indexY+1)+indexX;
     ind1=   5151*indexZ+101*(indexY+1)+indexX+1;
     //ind0=   20301*indexZ+201*(indexY+1)+indexX;
     //ind1=   20301*indexZ+201*(indexY+1)+indexX+1;
     C10x= MAGFieldX[ind0]*(1-xd)+MAGFieldX[ind1]*xd;
     C10y= MAGFieldY[ind0]*(1-xd)+MAGFieldY[ind1]*xd;
     C10z= MAGFieldZ[ind0]*(1-xd)+MAGFieldZ[ind1]*xd;

     ind0=   5151*(indexZ+1)+101*indexY+indexX;
     ind1=   5151*(indexZ+1)+101*indexY+indexX+1;
     //ind0=   20301*(indexZ+1)+201*indexY+indexX;
     //ind1=   20301*(indexZ+1)+201*indexY+indexX+1;
     C01x= MAGFieldX[ind0]*(1-xd)+MAGFieldX[ind1]*xd;
     C01y= MAGFieldY[ind0]*(1-xd)+MAGFieldY[ind1]*xd;
     C01z= MAGFieldZ[ind0]*(1-xd)+MAGFieldZ[ind1]*xd;

     ind0=   5151*(indexZ+1)+101*(indexY+1)+indexX;
     ind1=   5151*(indexZ+1)+101*(indexY+1)+indexX+1;
     //ind0=   20301*(indexZ+1)+201*(indexY+1)+indexX;
     //ind1=   20301*(indexZ+1)+201*(indexY+1)+indexX+1;
     C11x= MAGFieldX[ind0]*(1-xd)+MAGFieldX[ind1]*xd;
     C11y= MAGFieldY[ind0]*(1-xd)+MAGFieldY[ind1]*xd;
     C11z= MAGFieldZ[ind0]*(1-xd)+MAGFieldZ[ind1]*xd;

     //interpolation along y
     C0x = C00x*(1-yd)+C10x*yd;
     C1x = C01x*(1-yd)+C11x*yd;

     C0y = C00y*(1-yd)+C10y*yd;
     C1y = C01y*(1-yd)+C11y*yd;

     C0z = C00z*(1-yd)+C10z*yd;
     C1z = C01z*(1-yd)+C11z*yd;

     //interpolation along z
     Cx = C0x*(1-zd)+C1x*zd;
     Cy = C0y*(1-zd)+C1y*zd;
     Cz = C0z*(1-zd)+C1z*zd;

     // Final value for the B field
     Bfield[0] = -Cx*B0;
     Bfield[1] = -Cy*B0;    
     Bfield[2] = -Cz*B0;

   }
 // cout << " 3 " << Bfield[2] << " " << B0 << endl;

  
 // search indices for closest neighbours outside 
   if(x>-250&&x<250&&y<=0&&z>-40&&z<40&&y>-140)
 // if(x>-220&&x<220&&y<0&&z>-30&&z<30)
    {
       for (k=0;k<17;k++)
      // for (k=0;k<33;k++)
	{
	  if(z<=Z[k+1]&&z>=Z[k]) indexZ = k;
	}
      for (j=0;j<29;j++)
      //for (j=0;j<61;j++)
	{
	  if(y<=YY[j+1]&&y>=YY[j]) indexY = j;
	}
      for (i=0;i<101;i++)
       // for (i=0;i<201;i++)
	{
	  if(x<=X[i+1]&&x>=X[i]) indexX = i;  
	}
      //  G4cout << x << " " << indexX<< " "  << X[indexX] << " " << y << " " <<indexY<< " "  << Y[indexY]<< " " << z << " " << indexZ<< " " << Z[indexZ]<<endl;
    }
  
  if(x>-250.&&x<250.&&y<=0.&&z>-40.&&z<40.&&y>-140)
   {
     xd= (x-X[indexX])/(X[indexX+1]-X[indexX]);
     yd= (y-YY[indexY])/(YY[indexY+1]-YY[indexY]);
     zd= (z-Z[indexZ])/(Z[indexZ+1]-Z[indexZ]);


     //interpolation along X

     ind0=   2929*indexZ+101*indexY+indexX;
     ind1=   2929*indexZ+101*indexY+indexX+1;
     //ind0=   12261*indexZ+201*indexY+indexX;
     //ind1=   12261*indexZ+201*indexY+indexX+1;
     C00x= MAGFieldXO[ind0]*(1-xd)+MAGFieldXO[ind1]*xd;
     C00y= MAGFieldYO[ind0]*(1-xd)+MAGFieldYO[ind1]*xd;
     C00z= MAGFieldZO[ind0]*(1-xd)+MAGFieldZO[ind1]*xd;

     ind0=   2929*indexZ+101*(indexY+1)+indexX;
     ind1=   2929*indexZ+101*(indexY+1)+indexX+1;
     //ind0=   12261*indexZ+201*(indexY+1)+indexX;
     //ind1=   12261*indexZ+201*(indexY+1)+indexX+1;
     C10x= MAGFieldXO[ind0]*(1-xd)+MAGFieldXO[ind1]*xd;
     C10y= MAGFieldYO[ind0]*(1-xd)+MAGFieldYO[ind1]*xd;
     C10z= MAGFieldZO[ind0]*(1-xd)+MAGFieldZO[ind1]*xd;

     ind0=   2929*(indexZ+1)+101*indexY+indexX;
     ind1=   2929*(indexZ+1)+101*indexY+indexX+1;
     //ind0=   12261*(indexZ+1)+201*indexY+indexX;
     //ind1=   12261*(indexZ+1)+201*indexY+indexX+1;
     C01x= MAGFieldXO[ind0]*(1-xd)+MAGFieldXO[ind1]*xd;
     C01y= MAGFieldYO[ind0]*(1-xd)+MAGFieldYO[ind1]*xd;
     C01z= MAGFieldZO[ind0]*(1-xd)+MAGFieldZO[ind1]*xd;

     ind0=   2929*(indexZ+1)+101*(indexY+1)+indexX;
     ind1=   2929*(indexZ+1)+101*(indexY+1)+indexX+1;
     //ind0=   12261*(indexZ+1)+201*(indexY+1)+indexX;
     //ind1=   12261*(indexZ+1)+201*(indexY+1)+indexX+1;
     C11x= MAGFieldXO[ind0]*(1-xd)+MAGFieldXO[ind1]*xd;
     C11y= MAGFieldYO[ind0]*(1-xd)+MAGFieldYO[ind1]*xd;
     C11z= MAGFieldZO[ind0]*(1-xd)+MAGFieldZO[ind1]*xd;

     //interpolation along y
     C0x = C00x*(1-yd)+C10x*yd;
     C1x = C01x*(1-yd)+C11x*yd;

     C0y = C00y*(1-yd)+C10y*yd;
     C1y = C01y*(1-yd)+C11y*yd;

     C0z = C00z*(1-yd)+C10z*yd;
     C1z = C01z*(1-yd)+C11z*yd;

     //interpolation along z
     Cx = C0x*(1-zd)+C1x*zd;
     Cy = C0y*(1-zd)+C1y*zd;
     Cz = C0z*(1-zd)+C1z*zd;

     // Final value for the B field
     Bfield[0] = -Cx*B0*1.;
     Bfield[1] = -Cy*B0*1.;    
     Bfield[2] = -Cz*B0*1.;

   }
  // else
//    {
//      Bfield[0] =  0.;
//      Bfield[1] = 0.; 
//      Bfield[2] =  0. ;
//    } 
 
  if (y<5.&&x>-100.&&x<100.)
   {
     Bfield[0] =  0.;
     Bfield[1] = 0.; 
     Bfield[2] =  0. ;
   } 
 
  // cout << x << " " << y << " " << z << endl;
  //cout <<Bfield[0]  << " " << Bfield[1] << " " << Bfield[2] << endl; 

 // if(Bfield[2]!=0.&&x<0&&y>150&&fabs(sqrt(x*x+y*y)-180.)<1)
//  if(Bfield[2]!=0.&&x<0&&y<0)
//    {
//      cout << x << " " << y << " " << z << endl;
//      cout <<Bfield[0]  << " " << Bfield[1] << " " << Bfield[2] << endl; 
//    }


  Bfield[0] = Bfield[0]*(-corr+1);
  Bfield[1] = Bfield[1]*(-corr+1);
  Bfield[2] = Bfield[2]*(-corr+1);
  
}

