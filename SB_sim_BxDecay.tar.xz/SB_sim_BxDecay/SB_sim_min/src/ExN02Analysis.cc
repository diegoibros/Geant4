//////////////////////////////////////////////////////////////////////////
//   ExN02Analysis.cc                                                   //
//////////////////////////////////////////////////////////////////////////


//#include "Global.h"
//include "G4RunManager.hh"


#include "TH1D.h"
#include "TFile.h"
#include "TTree.h"
#include "TDirectory.h"

#include "ExN02Analysis.hh"


//ExN02Analysis* ExN02Analysis::instance = 0;

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....


ExN02Analysis::ExN02Analysis()
:runfile(0),X(0),Y(0),Z(0),Ener(0),Evt(0)
{
  //G4RunManager* runManager = G4RunManager::GetRunManager();
  TreeM =0; 

 
 
 /*
  TreeM->Branch("mtrack","Micro_Track",&mtrack,16000,99);
  TreeM->SetAutoSave(2000000);
  TreeM->SetDirectory(h);
  TreeM->SetBranchAddress("mtrack",&mtrack);
*/
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

ExN02Analysis::~ExN02Analysis() {

 if ( runfile ) delete runfile;
}

//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....
/*
void ExN02Analysis::Init()
{
}

void ExN02Analysis::Finish()
{
  //  analysisMessenger = 0;
}
*/

//ExN02Analysis* ExN02Analysis::getInstance(int argc,char** argv)
 void  ExN02Analysis::book()
{
   runfile = new TFile("ExN02.root","RECREATE");

  //mtrack = new Micro_Track();
  TreeM  = new TTree("TreeM","Spectro");
  TreeM->Branch("X", &X, "X/D");
  TreeM->Branch("Y", &Y, "Y/D");
  TreeM->Branch("Z", &Z, "Z/D");
  TreeM->Branch("PX", &PX, "PX/D");
  TreeM->Branch("PY", &PY, "PY/D");
  TreeM->Branch("PZ", &PZ, "PZ/D");
  TreeM->Branch("Xi", &Xi, "Xi/D");
  TreeM->Branch("Yi", &Yi, "Yi/D");
  TreeM->Branch("Zi", &Zi, "Zi/D");
  TreeM->Branch("PXi", &PXi, "PXi/D");
  TreeM->Branch("PYi", &PYi, "PYi/D");
  TreeM->Branch("PZi", &PZi, "PZi/D");
  TreeM->Branch("R", &R, "R/D");
  TreeM->Branch("Ener", &Ener, "Ener/D");
  TreeM->Branch("Evt", &Evt, "Evt/I");
  TreeM->Branch("EnerP", &EnerP, "EnerP/D");
  TreeM->Branch("Bin", &Bin, "Bin/I");
  TreeM->Branch("PID", &PID, "PID/I");
  TreeM->Branch("TID", &TID, "TID/I");
  TreeM->Branch("parent_ID", &parent_ID, "parent_ID/I");

 TreeP = new TTree("TreeP","Primaries");
 TreeP->Branch("Event_num", &event_numP, "Event_num/D");
 TreeP->Branch("Track_num", &track_numP, "Track_num/D"); 
 TreeP->Branch("PID", &PID_prim, "PID/D"); 
 TreeP->Branch("E_kin", &E_kinP, "Ener/D");
 TreeP->Branch("PX0", &PX0, "PX0/D");
 TreeP->Branch("PY0", &PY0, "PY0/D");
 TreeP->Branch("PZ0", &PZ0, "PZ0/D");


}

void ExN02Analysis::setNtuple1(G4ThreeVector pos, G4ThreeVector mom, int n, G4double kineP,int binkine, G4ThreeVector PosIni,G4ThreeVector VmomIni, G4int part_ID, G4int track_ID, G4int ID_parent)
{

  G4double m_e = 0.51099891;
  G4double Mom;
  //X = pos.x()/cm -18.;
   X = pos.x()/cm;
  Y = pos.y()/cm;
  Z = pos.z()/cm;
  PX = mom.x();
  PY=mom.y();
  PZ=mom.z();
  Xi = PosIni.x();
  Yi = PosIni.y();
  Zi = PosIni.z();
  PXi = VmomIni.x();
  PYi = VmomIni.y();
  PZi = VmomIni.z();

  R = sqrt(X*X+Z*Z) ;
  Evt = n;
  Mom = sqrt(mom.x()*mom.x() + mom.y()*mom.y() + mom.z()*mom.z());

  Ener = sqrt(Mom*Mom+m_e*m_e)-m_e;
  EnerP = kineP;
  Bin = binkine;
  PID = part_ID;
  TID = track_ID;
  part_ID = ID_parent;

  TreeM->Fill();
  // G4cout << "\n----> Histogram Tree is filled \n" << G4endl;
}


void ExN02Analysis::setNtuple2(G4int event_num, G4int track_num, G4int PID_pass, G4double E_kin, G4ThreeVector P0)
{

  event_numP = event_num;
  track_numP = track_num; 
  E_kinP = E_kin; 
  PID_prim = PID_pass; 
  PX0 = P0.x();
  PY0 = P0.y();
  PZ0 = P0.z();
  TreeP->Fill();
  // G4cout << "\n----> Histogram Tree is filled \n" << G4endl;
}




void ExN02Analysis::save()
{ 

  if (runfile) {
    runfile->Write();       // Writing the histograms to the file
    runfile->Close();        // and closing the tree (and the file)
    G4cout << "\n----> Histogram Tree is saved \n" << G4endl;
  }

}

/*
void ExN02Analysis::BeginOfRun(G4int n)
{

}

void ExN02Analysis::EndOfRun(G4int n)
{ 
  runfile->cd();
  TreeM->Write();
  runfile->ls();
  runfile->Close();
}
*/
//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

/* This member is called at the end of every event */
/*
void ExN02Analysis::EndOfEvent(G4int flag)
{
  // The plotter is updated only if there is some
  // hits in the event
  if(!flag) return;
 
}
*/







