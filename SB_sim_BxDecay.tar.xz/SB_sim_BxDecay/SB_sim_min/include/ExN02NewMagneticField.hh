
#include "G4ElectricField.hh"
#include "G4MagneticField.hh"
#include "G4UniformMagField.hh"

#include <vector>
#include <cmath>

#ifndef ExN02MagneticField_H
#define ExN02MagneticField_H

using namespace std;

class G4FieldManager;

class ExN02NewMagneticField : public G4MagneticField

{

  public: 
   //jplEMField();
  	ExN02NewMagneticField(G4double B_ref);

  	void GetFieldValue(const    G4double pos[4], 
                              G4double *Mfield) const;

  private:

  	G4double Bvalue_ref;

};
#endif
