#ifndef ExN02TrackingAction_hh
#define ExN02TrackingAction_hh 1

// Geant4:
#include "G4UserTrackingAction.hh"
#include "globals.hh"

class ExN02EventAction;
class ExN02Analysis;


class ExN02TrackingAction
  : public G4UserTrackingAction
{

public:  

  ExN02TrackingAction(ExN02EventAction*, ExN02Analysis*);

  ~ExN02TrackingAction() override;

  void PreUserTrackingAction(const G4Track*);

  void PostUserTrackingAction(const G4Track*) override;
    
private:
  
  ExN02EventAction * fEvent = nullptr;
  ExN02Analysis * analysis;
 
  
};

#endif // TrackingAction_hh