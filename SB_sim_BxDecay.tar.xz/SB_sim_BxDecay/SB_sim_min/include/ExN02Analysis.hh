

#ifndef ExN02Analysis_h
#define ExN02Analysis_h 1

#include "globals.hh"
#include "G4ThreeVector.hh"
#include "G4SystemOfUnits.hh"

/*
#include "TH1D.h"
#include "TFile.h"
#include "TTree.h"
*/

 class TFile;
 class TTree;
 class TH1D;

//class BrickAnalysisMessenger;
//class BrickDetectorConstruction;



//....oooOO0OOooo........oooOO0OOooo........oooOO0OOooo........oooOO0OOooo....

class ExN02Analysis {

public:

   ExN02Analysis();
  ~ExN02Analysis();
   void book();
   void save();

  // void BeginOfRun(G4int n);
  //void EndOfRun(G4int n);
  //void EndOfEvent(G4int flag);

  //void Init();
  //void Finish();

  void setNtuple1(G4ThreeVector pos, G4ThreeVector mom, int n, G4double kineP, int binkine, G4ThreeVector posini, G4ThreeVector vmomini, G4int part_ID, G4int track_ID, G4int ID_parent);
  void setNtuple2(G4int event_num, G4int track_num, G4int PID_pass, G4double E_kin, G4ThreeVector P0); 

  //static ExN02Analysis* getInstance(int = 0, char** = 0);

private:
  

private:
  //  static ExN02Analysis* instance;
  
  TFile* runfile;
  TTree *TreeM;
  TTree *TreeP;
 

  G4int Evt;
  G4double X;
  G4double Y;
  G4double Z;
  G4double Xi;
  G4double Yi;
  G4double Zi;
  G4double PX;
  G4double PY;
  G4double PZ;
  G4double PXi;
  G4double PYi;
  G4double PZi;
  G4double R;
  G4double Ener;
  G4double EnerP;
  G4int Bin;
  G4int PID;
  G4int TID;
  G4int parent_ID;

  G4double event_numP;
  G4double track_numP; 
  G4double E_kinP; 
  G4double PID_prim; 
  G4double PX0;
  G4double PY0;
  G4double PZ0;

  //ExN02AnalysisMessenger* analysisMessenger;
};

#endif

