
#include  <globals.hh>
#include "G4MagneticField.hh"
#include "G4ElectricField.hh"


#include <vector>
#include <cmath>

#include <fstream>
#include <vector>
#include <cmath>

#ifndef ExN02MagneticField_H
#define ExN02MagneticField_H


using namespace std;

class ExN02MagneticField 
#ifndef STANDALONE
: public G4MagneticField
#endif

{

  double MagVal;
  
  double X[101];
  double Y[51],YY[51];
  double Z[17];
  
  double MAGFieldX[87567];
  double MAGFieldZ[87567];
  double MAGFieldY[87567];
  double MAGFieldXO[49793];
  double MAGFieldZO[49793];
  double MAGFieldYO[49793];
  /*
  double X[201];
  double Y[101];
  double Z[33];
  double MAGFieldX[669933];
  double MAGFieldZ[669933];
  double MAGFieldY[669933];
  double MAGFieldXO[404613];
  double MAGFieldZO[404613];
  double MAGFieldYO[404613];
  */

  public: 
  ExN02MagneticField( const char* filename,const char* filename2, const G4double val, const G4double kine_new);

  void GetFieldValue(const    G4double pos[4], 
                              G4double *Bfield) const;

};
#endif
